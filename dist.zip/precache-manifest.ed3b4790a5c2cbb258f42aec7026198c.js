self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "233dd98d11b5510b5cd0",
    "url": "/css/app.802a23eb.css"
  },
  {
    "revision": "da7ccd42dc2c7a5f1871",
    "url": "/css/chunk-vendors.690b5669.css"
  },
  {
    "revision": "ea18151090f1a6e0a52566d50840c672",
    "url": "/img/C_Sharp_wordmark.ea181510.svg"
  },
  {
    "revision": "525f317fe9e90927edf7694d88ce42c8",
    "url": "/img/HTML5_logo_and_wordmark.525f317f.svg"
  },
  {
    "revision": "0e23f3710a61a4d3ce16edae6b9445cc",
    "url": "/img/NET_Core_Logo (1).0e23f371.svg"
  },
  {
    "revision": "0e23f3710a61a4d3ce16edae6b9445cc",
    "url": "/img/NET_Core_Logo.0e23f371.svg"
  },
  {
    "revision": "eed39aa6c5f4ce20ca2e60c0bdcae146",
    "url": "/img/VB.NET_Logo.eed39aa6.svg"
  },
  {
    "revision": "ecb4784c47f48b44c769dfcdea3ed313",
    "url": "/img/VsCode.ecb4784c.png"
  },
  {
    "revision": "9a45fc7689867939804c469bfcd17784",
    "url": "/img/Vue.js_Logo_2.9a45fc76.svg"
  },
  {
    "revision": "413b1cb5b08cf317cb1611006f283aa1",
    "url": "/img/gorgo_landing_page.413b1cb5.png"
  },
  {
    "revision": "f28215c9568cf8457cccd1d43ba738d8",
    "url": "/img/gorgo_registration.f28215c9.png"
  },
  {
    "revision": "e64c564a5fbface59ff0ce74619d41e8",
    "url": "/img/gorgo_talent_info.e64c564a.png"
  },
  {
    "revision": "69ada37a329b0edf7aae93c351187abf",
    "url": "/img/gorgo_talent_list.69ada37a.png"
  },
  {
    "revision": "ec3d418b93f1e9ef04290e2f3d2b664f",
    "url": "/img/irc_bulk_sms.ec3d418b.jpg"
  },
  {
    "revision": "85956d87a9ec26c35d72dd9a7142e357",
    "url": "/img/irc_bulk_sms_dashboard.85956d87.jpg"
  },
  {
    "revision": "f9739cd6f70c624d3b04b0eead571dac",
    "url": "/img/irc_bulk_sms_log_stats.f9739cd6.jpg"
  },
  {
    "revision": "0e6c7d4363afb739ab57c5275684a47f",
    "url": "/img/irc_dashboard.0e6c7d43.png"
  },
  {
    "revision": "5731b3bb6c8ec1294d41a019c5a55b4a",
    "url": "/img/irc_login.5731b3bb.png"
  },
  {
    "revision": "8c0a12579402eb9232e28f1c68b0ebcd",
    "url": "/img/irc_student_Info.8c0a1257.png"
  },
  {
    "revision": "a9e9675a941cbfc4a4129e5ad2c63a97",
    "url": "/img/jQuery.a9e9675a.gif"
  },
  {
    "revision": "b08f5b342afbec2f40485ae9120d002d",
    "url": "/img/javascript-736400_960_720.b08f5b34.webp"
  },
  {
    "revision": "7d82fb586787e0c04c77d2e8937ba5f3",
    "url": "/img/keep_calm_and_code.7d82fb58.jpg"
  },
  {
    "revision": "668f776478a9efe19b377a0b254a466c",
    "url": "/img/mark.668f7764.jpg"
  },
  {
    "revision": "075d4a52bc887845139850c80a2da667",
    "url": "/img/microsoft-net-logo.075d4a52.png"
  },
  {
    "revision": "653da89e5ece2401127f2240f13344f0",
    "url": "/img/mySql.653da89e.png"
  },
  {
    "revision": "fd33eea5d2a6abedc20c6129a1495215",
    "url": "/img/nuxt-js.fd33eea5.png"
  },
  {
    "revision": "58452263b4bb86d2ab0cd84d327b3599",
    "url": "/img/oms_dashboard.58452263.jpg"
  },
  {
    "revision": "5059faf6dbc3e934ed76f587ab368c7f",
    "url": "/img/oms_insights.5059faf6.jpg"
  },
  {
    "revision": "b1e059f8913bfa7a8139e9f62306945c",
    "url": "/img/oms_login.b1e059f8.jpg"
  },
  {
    "revision": "7ef812659cc8a21b8ed45e58cd02383e",
    "url": "/img/sql.7ef81265.svg"
  },
  {
    "revision": "e1a46762b2b5573600f28ab2ccff354f",
    "url": "/img/sqlServer.e1a46762.png"
  },
  {
    "revision": "2fec7e2443461f6c0f31ad55973bed79",
    "url": "/img/stl_dashboard.2fec7e24.png"
  },
  {
    "revision": "95db283adf1de577d83b8e07846ca6ec",
    "url": "/img/stl_employee_info.95db283a.png"
  },
  {
    "revision": "3f9be9257aad32c211c6944e3ed8f182",
    "url": "/img/stl_login.3f9be925.png"
  },
  {
    "revision": "668f776478a9efe19b377a0b254a466c",
    "url": "/img/thumbnail-mark.jpg"
  },
  {
    "revision": "94115de5a6cbcfca5d2548f33690774e",
    "url": "/img/vs2019.94115de5.svg"
  },
  {
    "revision": "cc2ed158a3f3dabf0fcb65967c995b71",
    "url": "/img/vs_code_background.cc2ed158.jpg"
  },
  {
    "revision": "8c3b03057d55fc17f357b8ebdfd6ca52",
    "url": "/img/vuetify.8c3b0305.svg"
  },
  {
    "revision": "8d242d312fee9869e6f8eb0e5c94429f",
    "url": "/img/webpack.8d242d31.png"
  },
  {
    "revision": "70ad98330d991043dcf250eae192e431",
    "url": "/img/xampp-logo.70ad9833.svg"
  },
  {
    "revision": "beaf320c79956464f3bded551d530595",
    "url": "/index.html"
  },
  {
    "revision": "233dd98d11b5510b5cd0",
    "url": "/js/app.a33b0d63.js"
  },
  {
    "revision": "da7ccd42dc2c7a5f1871",
    "url": "/js/chunk-vendors.e435845f.js"
  },
  {
    "revision": "599d91d82fb34828605bc57f89f65400",
    "url": "/logo.png"
  },
  {
    "revision": "136d872d9d7c24b95ecbc5a5674a7806",
    "url": "/manifest.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/offline.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);